
<nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="destino.php">Destinos </a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="p_viajes.php">Planes de viajes</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="c_resera.php">Consulta reserva </a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="A_cliente.php">Atencion al cliente</a>
      </nav>