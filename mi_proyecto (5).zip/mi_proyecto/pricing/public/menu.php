 <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="ropa.php">ROPA</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="calsado.php">CALSADO</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="p_hogar.php">PRODUCTOS PARA EL HOGAR</a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="p_electronicos.php">PRODUCTOS ELECTRONICOS</a>
      </nav>