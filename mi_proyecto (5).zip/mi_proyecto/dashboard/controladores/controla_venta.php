<?php


$valor = $_POST["valor"];
$edad = $_POST["edad"];
 $des = $valor * 0.2;
 
{
    //si entra a ca es porque es mayor de edad
    echo "tome guaro ";

}else{
    //si entra a ca es porque es menor  de edad
echo "eche pa la casa menor ";
}
echo $nombre." - ".$documento;