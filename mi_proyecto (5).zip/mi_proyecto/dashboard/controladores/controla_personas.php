<?php


$nombre = $_POST["nombre"];
$documento = $_POST["documento"];
$edad = $_POST["edad"];
if($edad>=18)
{
    //si entra a ca es porque es mayor de edad
    echo "tome guaro ";

}else{
    //si entra a ca es porque es menor  de edad
echo "eche pa la casa menor ";
}
echo $nombre." - ".$documento;
?>