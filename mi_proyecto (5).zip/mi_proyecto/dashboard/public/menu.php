<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="prematricula.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Pre matricula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="financiera.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Matricula Financiera 
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="individual.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Matricula Individual
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="notas.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                notas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="horarios.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Horarios 
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="certificado de notas.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Certificado de Notas 
              </a>
            </li>
          </ul>